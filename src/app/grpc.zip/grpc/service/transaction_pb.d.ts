import * as jspb from "google-protobuf"

import * as model_transaction_pb from '../model/transaction_pb';
import * as google_api_annotations_pb from '../google/api/annotations_pb';

