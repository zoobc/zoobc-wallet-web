import * as jspb from "google-protobuf"

import * as model_nodeRegistration_pb from '../model/nodeRegistration_pb';
import * as google_api_annotations_pb from '../google/api/annotations_pb';

