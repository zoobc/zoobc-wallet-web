import * as jspb from "google-protobuf"

import * as model_block_pb from '../model/block_pb';
import * as google_api_annotations_pb from '../google/api/annotations_pb';

