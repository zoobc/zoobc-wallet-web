import * as jspb from "google-protobuf"

export enum RequestType { 
  GetNodeHardware = 0,
}
